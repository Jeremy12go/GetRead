//Código de prueba para iniciar sesión en una cuenta en base a AccountController.js
const { login } = require('../controllers/AccountController');
const Account = require('../models/Account');

// Mock del modelo Account
jest.mock('../models/Account');
describe("login controller", () => {
  let req, res;
  beforeEach(() => {
    req = {
      body: {
        email: "test@example.com",
        password: "securepassword"
      }
    };
    res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn()
    };
  });

  it("should successfully login", async () => {
    const mockProfile = { name: "Test User" };
    const mockAccount = { email: req.body.email, password: req.body.password, profile: mockProfile };
    Account.findOne.mockResolvedValue(mockAccount);
    await login(req, res);
    expect(res.json).toHaveBeenCalledWith(mockProfile);
  });

  it("should return 404 if account not found", async () => {
    Account.findOne.mockResolvedValue(null);
    await login(req, res);
    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith({ error: "Perfil no encontrado para ese correo" });
  });

  it("should return 401 if credentials are invalid", async () => {
    const mockAccount = { email: req.body.email, password: "wrongpassword", profile: {} };
    Account.findOne.mockResolvedValue(mockAccount);
    await login(req, res);
    expect(res.status).toHaveBeenCalledWith(401);
    expect(res.json).toHaveBeenCalledWith({ error: "Credenciales inválidas" });
  });

  it("should return 500 on server error", async () => {
    Account.findOne.mockImplementation(() => { throw new Error("Server error"); });
    await login(req, res);
    expect(res.status).toHaveBeenCalledWith(500);
    expect(res.json).toHaveBeenCalledWith({ error: "Error al obtener perfil", detalle: "Server error" });
  });
});