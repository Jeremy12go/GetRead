//Código para actualizar una orden en base a OrderController.js

const { update } = require('../controllers/OrderController');
const Order = require('../models/Order'); // importa tu modelo

// Mock del modelo Order
jest.mock('../models/Order');
describe('updateOrder', () => {
    afterEach(() => {
        jest.clearAllMocks();
    });

    it('debería actualizar una orden correctamente', async () => {
        const req = {
            params: { id: 'orderId123' },
            body: { product: { id: 'prod1', quantity: 2 } }
        };
        const res = {
            json: jest.fn(),
            status: jest.fn().mockReturnThis()
        };
        const order = { id: 'orderId123', productList: [{ id: 'prod1', quantity: 2 }] };

        Order.findOneAndUpdate.mockResolvedValue(order);

        await update(req, res);
        expect(Order.findOneAndUpdate).toHaveBeenCalledWith(
            { id: 'orderId123' },
            { $push: { productList: req.body.product } },
            { new: true, runValidators: true }
        );
        expect(res.json).toHaveBeenCalledWith(order);
    });

    it('debería devolver 404 si la orden no se encuentra', async () => {
        const req = {
            params: { id: 'nonExistentOrderId' },
            body: { product: { id: 'prod1', quantity: 2 } }
        };
        const res = {
            json: jest.fn(),
            status: jest.fn().mockReturnThis()
        };
        Order.findOneAndUpdate.mockResolvedValue(null);
        await update(req, res);

        expect(res.status).toHaveBeenCalledWith(404);
        expect(res.json).toHaveBeenCalledWith({ error: 'Orden no encontrada' });
    });

    it('debería manejar errores al actualizar la orden', async () => {
        const req = {
            params: { id: 'orderId123' },
            body: { product: { id: 'prod1', quantity: 2 } }
        };
        const res = {
            json: jest.fn(),
            status: jest.fn().mockReturnThis()
        };
        Order.findOneAndUpdate.mockRejectedValue(new Error('DB error'));

        await update(req, res);
        expect(res.status).toHaveBeenCalledWith(400);
        expect(res.json).toHaveBeenCalledWith({ error: 'Error al actualizar', detalle: 'DB error' });
    });
});